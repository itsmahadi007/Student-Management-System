package sample;

public class AdminTablrView {

     public String Id;
     public String name;
     public String Year;
    public String getId()
    {
        return this.Id;
    }
    public  String getName()
    {
        return this.name;
    }
    public  String getYear()
    {
        return this.Year;
    }
}
