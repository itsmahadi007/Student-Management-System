package sample;

public class StudentTableView {
    public String code;
    public String Mod;
    public String Grd;

    public String getCode() {
        return code;
    }

    public String getMod() {
        return Mod;
    }

    public String getGrd() {
        return Grd;
    }
}
